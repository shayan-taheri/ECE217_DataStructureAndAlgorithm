
#ifndef FAMILY_H
#define FAMILY_H

#include <iostream>
#include <string>
#include "Person.h"
using namespace std;

class Family
{
  private:
    int _size;			// number of family members
    Person *f;			// array of family members (size of array == number of family members)

  public:
    Family (int size);		// 'size' is number of family members 
    ~Family();			// destructor

    void addFamilyMember (int i, Person p);	// "add" a family member by passing in Person object
						//      and storing it in i-th array position
    Person getFamilyMember (int i) const;	// get family member at i-th array position

    bool findPerson (string firstName) const;	// check if a person with the given firstname is in Family
    string getParents () const;			// return a list of all family members who are parents
						//	(i.e. "Father", "father", "Mother", or "mother"
    string getChildren () const;		// return a list of all family members who are kids
};

#endif

